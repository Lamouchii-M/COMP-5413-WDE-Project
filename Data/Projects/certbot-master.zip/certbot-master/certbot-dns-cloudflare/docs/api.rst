=================
API Documentation
=================

Certbot plugins implement the Certbot plugins API, and do not otherwise have an external API.
